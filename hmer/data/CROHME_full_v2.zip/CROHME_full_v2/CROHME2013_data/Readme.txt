Please do not distribute this unofficial data set. An official version will bsoon be available on the CROHME website and/or on the TC11's data set page.

Content: 

TrainINKML/ : all training inkml files sorted by origin
TestINKML/ : inkml test files without ground-truth, used to run the participants systems.
TestINKMLGT/ : inkml test files with ground-truth, used to evaluate the participants systems with the evalinkml tool.
Test_LG/Test2012LG/ Test_LG/Test2013LG/: label graph version of the test files for 2012 and 2013 dataset, using inherited edges (so the graphs are DAG).
Test_LG/Test2012LG_TREE/ Test_LG/Test2013LG_TREE/: label graph version of the test files for 2012 and 2013 data set, without inherited edges (so the graphs are trees).

NOTE: The position of the 'prime' symbol was not clear in the competition task : should it be in superscript or in the same row as the reference symbol ? Thus, to save participants time, we defined a second version of the test set with prime in ROW instead of asking to change the recognition systems. Please consider that the official way is the prime in superscript. The "prime in row" data sets are given only to be able to re-compute the results.

CROHME organization committee

